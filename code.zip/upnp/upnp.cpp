
#include <windows.h>
#include <upnp.h>

#include <stdio.h>
#include <assert.h>

int main() {
    CoInitialize(0);

    IUPnPDeviceFinder *finder = 0;
    CoCreateInstance(CLSID_UPnPDeviceFinder,
                     0,
                     CLSCTX_INPROC_SERVER,
                     IID_IUPnPDeviceFinder,
                     (void **) &finder);

    assert(finder);

    printf("\n\nInitialized device finder\nSearching for devices...\n\n");

    IUPnPDevices *devices = 0;
    finder->FindByType(L"ssdp:all", 0, &devices);

    long device_count = 0;
    devices->get_Count(&device_count);
    printf("found %ld UPnP devices!\n\n", device_count);
    fflush(stdout);

    IEnumVARIANT *enumerator = 0;
    devices->get__NewEnum((LPUNKNOWN *)&enumerator);

    VARIANT variant;
    unsigned long fetched;
    for (long i = 0; i < device_count; ++i) {
        enumerator->Next(1, &variant, &fetched);
        assert(fetched == 1);

        IUPnPDevice *device = (IUPnPDevice *)variant.punkVal;

        BSTR tmp;

        device->get_UniqueDeviceName(&tmp);
        printf("UPnP Device %S\n", tmp);

        device->get_Type(&tmp);
        printf("\tType: %S\n", tmp);

        device->get_ModelName(&tmp);
        printf("\tModel Name: %S\n", tmp);

        device->get_Description(&tmp);
        if (!tmp || tmp[0] == 0) tmp = L"[No description provided]";
        printf("\tDesc: %S\n", tmp);

        IUPnPServices *services = 0;
        device->get_Services(&services);
        long service_count = 0;
        services->get_Count(&service_count);
        if (service_count) {
            printf("\tservices: %ld\n", service_count);
            IEnumVARIANT *service_enum = 0;
            services->get__NewEnum((LPUNKNOWN *)&service_enum);
            unsigned long services_fetched = 0;
            for (long j = 0; j < service_count; ++j) {
                service_enum->Next(1, &variant, &services_fetched);
                if (services_fetched == 1) {
                    IUPnPService *service = (IUPnPService *)variant.punkVal;
                    service->get_ServiceTypeIdentifier(&tmp);
                    printf("\t\t%S\n", tmp);
                } else {
                    printf("\t\t[unable to retrieve service]\n");
                    break;
                }
            }
        }

        printf("\n");
    }
}
