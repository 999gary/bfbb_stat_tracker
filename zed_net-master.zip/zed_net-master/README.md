# zed_net
zed_net is a single file, public domain library that provides a simple wrapper around BSD sockets (Winsock 2.2 on Windows), intended primary for use in games. Only UDP sockets are supported at this time, but this may later expand to include TCP.

This is my first library, and any suggestions/concerns are welcomed! ([@TheZedZull](https://twitter.com/TheZedZull) or thezedzull -at- gmail -dot- com)
